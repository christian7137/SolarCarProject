/************************************
  -
  - file: svtShutdownSensor.cpp
  -
  - purpose: instance of svtSensor for K65F onboard accelerometer.
  -
  - author: J. C. Wiley, Feb. 2015
  -     ADAFruit GPS Ultra sensor
  -
*************************************/
#include "svtShutdownSensor.h"

/** svtShutdownSensor - Constructor
*/
svtShutdownSensor::svtShutdownSensor(PinName ubPin):UserButton(ubPin){
     InShutdown = false;
}
svtShutdownSensor::svtShutdownSensor(PinName ubPin, PinMode amode):UserButton(ubPin, amode){
     InShutdown = false;
}
/** svtShutdownSensor - Destructor
*/
svtShutdownSensor::~svtShutdownSensor(){

};

/** init - initializes after construction (overrides)
*/
int svtShutdownSensor::init(){ 
    int status = 0;
    InShutdown = false;
    return status;
}

/** readSensor - overrides virtual base class function
 *  data for three CAN msgs stored in gc, and should be current
 *  put three messages on CAN output queue.
*/
int svtShutdownSensor::readSensor(){
     CANMessage msg;
     msg.id     = CANbase + 4;
     msg.len    = 8;
     msg.type   = CANData;
     msg.format = CANStandard;
     msg.data[0] =  1;  // true -> shutdown
     msg.data[1] =  0;
     msg.data[2] =  0;
     msg.data[3] =  0; 
     msg.data[4] =  0;
     msg.data[5] =  0;
     msg.data[6] =  0;
     msg.data[7] =  0;
     if(sendOutMsg(msg) != 0){
	 udebug.printf(" mem fail in sendOutMsg 1 \r\n"); 
     }
     return 0;
}

/** command - receive command via CAN message
 *     a command may tell sensor to change internal settings
 *     or initiate an activity
 */
int svtShutdownSensor::command(CANMessage& m){
    return 0;
}

/** update - update is called at the requested interval
 */
void svtShutdownSensor::update(){
    if(UserButton.Down() && !InShutdown){
	InShutdown = true; // only send message once
        udebug.printf("sending shutdown msg \r\n");
        readSensor(); //  sends CAN messages.
    }
}

