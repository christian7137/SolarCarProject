/************************************
  -
  - file: svtShutdownSensor.h  
  -
  - purpose: svtSensor to monitor shutdown switch
  -     whose physicsl position may change
  -
  - author: J. C. Wiley, April 2017
  -
  -  Note: This is an almost trival example of a sensor
  -
*************************************/
#ifndef svtShudownsensor_H
#define svtShudownsensor_H

#include "svtSensor.h"
#include "svtSwitch.h"

/** svtShutdownSensor  
 *  
 */
class svtShutdownSensor: public svtSensor {
public:
    /** svtGPSsensor - Constructor
     */
    svtShutdownSensor(PinName ub);
    svtShutdownSensor(PinName ub, PinMode amode);

    /** svtGPS - Destructor
     */
    ~svtShutdownSensor();

    /** init - initializes after construction (overrides)
     */
    virtual int init();

    /** readSensor - overrides virtual base class function
     */
    virtual int readSensor();

    /** command - receive command via CAN message
     *     a command may tell sensor to change internal settings
     *     or initiate an activity
     */
    virtual int command(CANMessage& m);

    /** update - update is called at the requested interval
     */
    virtual void update();

    svtSwitch UserButton;  // on one Nucleo, use User Button to start shutdown.

private:
    bool InShutdown;
};   
#endif
